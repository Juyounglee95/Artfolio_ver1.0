package com.example.user.artfolio_ver10;

/**
 * Created by user on 2017-11-28.
 */

public class dash_thum_pic {
    private String image_url;


    public dash_thum_pic(String image_url) {
        this.image_url = image_url;
    }


    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }
}
